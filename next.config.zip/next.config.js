module.exports = {
  reactStrictMode: true,
  exportPathMap: async function (
    defaultPathMap,
    { dev, dir, outDir, distDir, buildId }
  ) {
    return {
      '/': { page: '/' },
      '/ruta1': { page: '/ruta1' }
      // Agrega tus rutas aquí
    }
  }
}
