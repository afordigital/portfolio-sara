"use strict";
exports.id = 225;
exports.ids = [225];
exports.modules = {

/***/ 7225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "wY": () => (/* binding */ Tables),
  "G$": () => (/* binding */ TablesLabExp),
  "Pf": () => (/* binding */ complexProjects),
  "q": () => (/* binding */ projects),
  "at": () => (/* binding */ renders)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/common/skill.js


const Skill = ({ image , description  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col space-y-2",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: image,
                        alt: "skill icon",
                        width: 60,
                        height: 60,
                        objectFit: "contain"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "flex justify-center",
                    children: description
                })
            ]
        })
    });
};
/* harmony default export */ const skill = (Skill);

// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./config/projects.js




const projects = [
    {
        title: "Priorizaci\xf3n de Leads",
        description: "SaaS que recoge el hist\xf3rico del usuario y gracias a modelos predictivos le permite mejorar la conversi\xf3n de clientes potenciales."
    },
    {
        title: "Calculadora Solar",
        description: "Calculadora Solar hecha con JavaScript, HTML, CSS e introducci\xf3n a php para calcular los datos de compra del usuario."
    },
    {
        title: "Posicionamiento Web 24",
        description: "P\xe1gina est\xe1tica realizada con React, NextJS y Tailwindcss con tarifas para vender posicionamiento web, dise\xf1o original con Figma."
    },
    {
        title: "Alessio Muganni",
        description: "Portfolio de m\xfasico reconocido realizado con React, NextJS y Tailwindcss, dise\xf1o original con Figma."
    }
];
const renders = [
    "/preview-8.jpg",
    "/preview-2.jpg",
    "/preview-10.jpg",
    "/preview-9.jpg",
    "/preview-1.jpg",
    "/preview-4.jpg"
];
const complexProjects = [
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaNetworkWired, {}),
        title: "Previsi\xf3n de Leads",
        src: "/proyecto6.JPG",
        description: "Desarrollo de un SaaS basado en Inteligencia Artificial que a trav\xe9s de modelos predictivos usa el hist\xf3rico de datos del usuario y permite mejorar la conversi\xf3n de leads.",
        softwares: "React | Tailwindcss | AWS",
        hrefbutton: "https://fiuter-app.com/"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalculator, {}),
        title: "Calculadora Solar",
        src: "/proyecto1.JPG",
        description: "Proyecto de calculadora solar realizado con JavaScript con un algoritmo de c\xe1lculo donde dependiendo de la orientaci\xf3n de tu tejado, el \xe1rea de tu mapa importado con la librer\xeda Leaflet y vatios consumidos entre otros par\xe1metros, calcula qu\xe9 objetos necesitas para pasarte a usar energ\xeda solar y cu\xe1ndo lo rentabilizas.",
        softwares: "JavaScript | HTML | CSS | PHP | Wordpress",
        hrefbutton: "https://sima.mandarinaservices.com/calculadora/%27%7D"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaChalkboard, {}),
        title: "Posicionamiento Web",
        src: "/proyecto2.JPG",
        description: "P\xe1gina est\xe1tica realizada creada para facilitar la informaci\xf3n de servicios de posicionamiento web con distintas tarifas con el objetivo de venta de estos servicios. Dise\xf1o original hecho en Figma.",
        softwares: "React | NextJS | TailwindCSS",
        hrefbutton: "https://posicionamiento-web.vercel.app/"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCamera, {}),
        title: "Alessio Muganni",
        src: "/proyecto3.JPG",
        description: "P\xe1gina est\xe1tica de portfolio de un fot\xf3grafo, con su informaci\xf3n personal, mapa y un cuadro de contacto con validaci\xf3n de usuario realizada en Yup. Dise\xf1o original hecho en Figma.",
        softwares: "React | NextJS | TailwindCSS",
        hrefbutton: "https://prueba-navy.vercel.app/"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaShip, {}),
        title: "Puerto de Los \xc1ngeles",
        src: "/proyecto4.JPG",
        description: "Interfaz sencilla realizada en JavaScript y Verge3D que combina 3D y programaci\xf3n. A trav\xe9s de la leyenda de la interfaz puedes acceder a los puntos que te muestran giros de c\xe1mara e informaci\xf3n sobre distintas secciones para mejorar la seguridad portuaria.",
        softwares: "JavaScript | HTML | CSS | Verge3D",
        hrefbutton: "https://app.estudiocactus.com/visitor-hsse/map/losAngeles/"
    }
];
const Tables = [
    {
        title: "Frontend",
        skill1: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/react.svg",
            description: "React"
        }),
        skill2: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/nextjs.svg",
            description: "NextJS"
        }),
        skill3: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/js.svg",
            description: "JavaScript"
        }),
        skill4: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/html.svg",
            description: "HTML"
        }),
        skill5: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/css.svg",
            description: "CSS"
        })
    },
    {
        title: "Dise\xf1o Gr\xe1fico",
        skill1: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/figma.svg",
            description: "Figma"
        }),
        skill2: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/photoshop.svg",
            description: "Photoshop"
        }),
        skill3: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/illustrator.svg",
            description: "Illustrator"
        }),
        skill4: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/indesign.svg",
            description: "InDesign"
        }),
        skill5: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/after-effects.svg",
            description: "After Effects"
        })
    },
    {
        title: "Softwares 3D",
        skill1: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/3dsmax.svg",
            description: "3ds Max"
        }),
        skill2: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/vray.svg",
            description: "V-Ray 5"
        }),
        skill3: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/verge.svg",
            description: "Verge 3D"
        }),
        skill4: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/blender.svg",
            description: "Blender"
        })
    },
    {
        title: "Herramientas",
        skill1: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/github.svg",
            description: "Github"
        }),
        skill2: /*#__PURE__*/ jsx_runtime_.jsx(skill, {
            image: "/resume-icons/vs-code.svg",
            description: "VS Code"
        })
    }
];
const TablesLabExp = [
    {
        title: "Desarrolladora Frontend",
        place: "Fiuter, Madrid",
        iconPlace: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegBuilding, {}),
        date: "Sept 2022 - Actual",
        iconDate: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendarAlt, {}),
        description: "Retos enfrentados en esta start-up:",
        labor1: "Desarrollo de un SaaS que automatiza la creaci\xf3n de modelos de priorizaci\xf3n de leads en base a un hist\xf3rico de datos. Creaci\xf3n de la plataforma con React, Tailwindcss y AWS.",
        labor2: "Desarrollo de una plataforma en React integrada en Shopify que permite a los due\xf1os de e-commerces generar segmentaci\xf3n inteligente para sus campa\xf1as de marketing.",
        labor3: "Organizaci\xf3n del equipo t\xe9cnico a trav\xe9s de la metodolog\xeda \xe1gil Scram.",
        showList: true
    },
    {
        title: "Artista T\xe9cnica y Desarrolladora Frontend",
        place: "Estudio Cactus, Castell\xf3n",
        iconPlace: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegBuilding, {}),
        date: "Sept 2021 - Sept 2022",
        iconDate: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendarAlt, {}),
        description: "Retos enfrentados en esta consultor\xeda tecnol\xf3gica:",
        labor1: "Desarrollo de aplicaciones 3D con softwares actuales como Verge3D, JavaScript, HTML y CSS.",
        labor2: "Creaci\xf3n de Landing Pages con React, NextJS y Tailwindcss.",
        labor3: "Realizaci\xf3n de im\xe1genes CGI en 3ds Max y V-Ray 5 con m\xfaltiples estilos de interiorismo.",
        showList: true
    },
    {
        title: "Programadora Web",
        place: "Mandarina Webs, Valencia",
        iconPlace: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegBuilding, {}),
        date: "Aut\xf3noma",
        iconDate: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendarAlt, {}),
        description: "Retos enfrentados en esta empresa de marketing digital:",
        labor1: "Desarrollo de un plugin para Wordpress consistente en una calculadora solar.",
        labor2: "Realizaci\xf3n de un branding profesional para una tienda de ropa.",
        labor3: "Venta de servicios web como teleoperadora y vendedora.",
        showList: true
    },
    {
        title: "Artista en CGI",
        place: "Nuxot, Catell\xf3n",
        iconPlace: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaRegBuilding, {}),
        date: "Enero 2021 - Junio 2021",
        iconDate: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendarAlt, {}),
        description: "Retos enfrentados en esta empresa: ",
        labor1: "Realizaci\xf3n de im\xe1genes CGI para arquitectura en 3ds Max y V-Ray 5.",
        labor2: "Postprocesado de im\xe1genes en Photoshop.",
        labor3: "Estudio y creaci\xf3n de materiales PBR.",
        showList: true
    }
];


/***/ })

};
;